const axios = require('axios');



async function curlFunction(d, curlcall) {
    const baseUrl = 'https://apitest.axxess.co.za/calls/rsapi/';
    const username = 'ResellerAdmin';
    const password = 'jFbd5lg7Djfbn48idmlf4Kd';
    const authHeader = Buffer.from(`${username}:${password}`).toString('base64');
    const headers = {
        'Authorization': `Basic ${authHeader}`,
        'Content-Type': 'application/json',
        'Accept': 'application/json',
    };

    try {
        let response;
        console.log(curlcall);
        switch (curlcall) {
            case 'getSession':
                response = await axios.get(`${baseUrl}getSession.json`, { headers, params: d });
                break;

            case 'checkSession':
                response = await axios.get(`${baseUrl}checkSession.json`, { headers, params: d });
                break;

            case 'getProvinces':
                response = await axios.get(`${baseUrl}getProvinces.json`, { headers, params: d });
                break;

            case 'getAllClients':
                response = await axios.get(`${baseUrl}getAllClients.json`, { headers, params: d });
                break;

            case 'getClientById':
                response = await axios.get(`${baseUrl}getClientById.json`, { headers, params: d });
                break;

            case 'createClient':
                response = await axios.put(`${baseUrl}createClient.json`, d, { headers });
                break;

            case 'getProducts':
                response = await axios.get(`${baseUrl}getProducts.json`, { headers, params: d });
                break;

            case 'getServicesByClient':
                response = await axios.get(`${baseUrl}getServicesByClient.json`, { headers, params: d });
                break;

            case 'getAllUnassignedSimServices':
                response = await axios.get(`${baseUrl}getAllUnassignedSimServices.json`, { headers, params: d });
                break;

            case 'getServiceSessionDetailsById':
                response = await axios.get(`${baseUrl}getServiceSessionDetailsById.json`, { headers, params: d });
                break;

            case 'getServiceUsageDetailsById':
                response = await axios.get(`${baseUrl}getServiceUsageDetailsById.json`, { headers, params: d });
                break;

            case 'createService':
                response = await axios.put(`${baseUrl}createService.json`, d, { headers });
                break;

            case 'funcServiceChanges':
                response = await axios.put(`${baseUrl}funcServiceChanges.json`, d, { headers });
                break;

            case 'funcTopups':
                response = await axios.put(`${baseUrl}funcTopups.json`, d, { headers });
                break;

            case 'funcPod':
                response = await axios.get(`${baseUrl}funcPod.json`, { headers, params: d });
                break;

            case 'funcSuspend':
                response = await axios.get(`${baseUrl}funcSuspend.json`, { headers, params: d });
                break;

            case 'funcFixLine':
                response = await axios.get(`${baseUrl}funcFixLine.json`, { headers, params: d });
                break;

            case 'funcCheckLine':
                response = await axios.get(`${baseUrl}funcCheckLine.json`, { headers, params: d });
                break;

            case 'funcPasswordReset':
                response = await axios.get(`${baseUrl}funcPasswordReset.json`, { headers, params: d });
                break;
            
            case 'checkFibreAvailability':
            response = await axios.get(`${baseUrl}checkFibreAvailability.json`, { headers, params: d });
            break;
        
            case 'createFibreComboService':
                response = await axios.put(`${baseUrl}createFibreComboService.json`, d, { headers });
                break;
            
        // Add cases for other API calls as needed

            default:
                throw new Error('Invalid curlcall parameter');
        }

        return response.data;
    } catch (error) {
        console.error('Error:', error.response ? error.response.data : error.message);
        throw error;
    }
}



module.exports = curlFunction;
