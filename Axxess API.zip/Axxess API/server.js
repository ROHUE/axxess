const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const curlFunction = require('./axxess_api/axxessAPI');
var sessionId = "";

const app = express();
const port = 3000; // Choose a port number

app.use(cors());
app.use(bodyParser.json());

// Endpoint for getSession
app.post('/getSession', async (req, res) => {
  try {
    const credentials = { strUserName: 'JIY24', strPassword:  '_x7#PC~Bd%J&s%v'};
    const { data, curlCall } = req.body;
    const result = await curlFunction(credentials, curlCall);
    sessionId = result['strSessionId'];
    res.json(result);
  } catch (error) {
    console.error('Error:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

// Endpoint for checkSession
app.post('/checkSession', async (req, res) => {
  try {
    const { data, curlCall } = req.body;
    const result = await curlFunction(data, curlCall);
    res.json(result);
  } catch (error) {
    console.error('Error:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

// Endpoint for getProvinces
app.post('/getProvinces', async (req, res) => {
  try {
    const { data, curlCall } = req.body;
    const result = await curlFunction(data, curlCall);
    res.json(result);
  } catch (error) {
    console.error('Error:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

// Endpoint for getAllClients
app.post('/getAllClients', async (req, res) => {
  try {
    const { data, curlCall } = req.body;
    const result = await curlFunction(data, curlCall);
    res.json(result);
  } catch (error) {
    console.error('Error:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

// Endpoint to check fibre availability
app.post('/checkFibreAvailability', async (req, res) => {
    try {
        const { data, curlCall } = req.body;
        console.log('server: ' + JSON.stringify(req.body));
        const result = await curlFunction(data, curlCall);
        res.json(result);
      } catch (error) {
        console.error('Error:', error);
        res.status(500).json({ error: 'Internal Server Error' });
      }
});

// Test endpoint
app.get('/test', (req, res) => {
    res.send('This is a test endpoint for stuff!');
});

// Add more endpoints as needed

app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});
